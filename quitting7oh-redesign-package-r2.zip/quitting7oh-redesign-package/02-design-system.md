# 02 — Design System Spec (Rev 2)

**The source of truth for base tokens is the branch itself**: `src/styles/global.css` on `experiment/chatgpt-redesign` — the "Field Guide" system. This document records those values, then specifies the rev-2 extensions. The mockups' `:root` blocks express the same system in plain hex for quick reference.

## Base tokens (already on the branch — do not reinvent)

Defined as shadcn-style HSL triplets consumed via `@theme inline` (Tailwind 4):

| Token (light) | HSL | ≈Hex | Role |
|---|---|---|---|
| `--background` | `43 38% 97%` | `#F8F5EF` | warm paper |
| `--card` | `44 44% 99%` | `#FEFDFB` | raised surfaces |
| `--secondary` / `--muted` | `38 24% 91%` / `40 25% 93%` | `#EDE8DF` | wells, fills |
| `--foreground` | `22 16% 14%` | `#2A211C` | ink |
| `--muted-foreground` | `24 10% 36%` | `#655A52` | secondary text |
| `--border` / `--input` | `38 20% 82%` / `38 22% 78%` | `#DAD3C6` | lines |
| `--primary` | `15 42% 38%` | `#8A4632` | **burnt clay** — actions, links, active nav |
| `--accent` | `20 31% 91%` | `#F0E5DF` | clay-tinted fill |
| `--signal` | `35 88% 46%` | amber | caution semantics, ban banner |
| `--success` | `104 35% 34%` | laurel | live/positive semantics |
| `--destructive` | `2 62% 43%` | `#B2312A` | danger semantics |
| `--ring` | `15 50% 42%` | | 3px focus outline (keep) |

Dark theme mirrors these warm-shifted (`--background: 22 14% 8%`, `--primary: 18 48% 70%` etc.). Radius scale `0.35/0.55/0.8/1.1rem`. Clay accent scale `--color-accent-50…950` (#fcf6f3 → #2e1713).

**Fonts (already on the branch):** `Newsreader Variable` (display, self-hosted via Fontsource) and `Atkinson Hyperlegible Next Variable` (body/UI, weight ~430 base). Keep both; they are the identity now.

### Rev-2 token adjustments (small, deliberate)

- **Dark surfaces, lifted ~2–3 lightness points** to reduce halation: background `22 14% 8%` → **`22 14% 10–11%`** (≈`#211A15`), card `22 13% 11%` → **`~13%`** (≈`#2A221C`), with borders raised to match (≈`24 11% 27%`). Verify AA for clay-on-dark link text after the lift.
- **No pure white text on fills in dark mode** — filled clay/destructive buttons take near-black warm text (`#2A1710`-ish), as the branch's `--primary-foreground` dark value already does.
- Everything else stays as the branch defines it.

## Typography (rev-2 reading scale)

| Role | Size (desktop / mobile) | Notes |
|---|---|---|
| h1 | 40 / 30–34 | Newsreader, weight ~600, `letter-spacing -0.01em`, lh 1.15 |
| h2 | 26 / 22 | 40px top margin |
| Lede | 20 / 18.5 | muted-foreground, lh 1.55 |
| **Article body** | **18 / 17** | lh 1.65–1.7 — up from the branch's 16px; Atkinson earns its keep at reading sizes |
| UI body | 16–17 | branch default fine |
| Small/meta | 13.5–14.5 | |
| Eyebrows/labels | 12.5–13 | uppercase, `.08em`, 600 — the branch's field-note style |

Measure: **68–72ch** for articles. Left-aligned, never justified. Nothing below 16px except metadata.

## Components

### Urgency care-cards (the centerpiece of rev 2 — see `mockup-doc-page.html`)

Replace/extend `Callout.tsx`'s rendering for the two urgent tiers. Anatomy: 1px border in tier color, tinted body background, **solid header bar** in tier color carrying an icon + action heading ending in "…if:", body with bulleted criteria at full text size and full contrast (not muted), optional small footer line. Header text: white in light mode, warm near-black in dark. Include an sr-only urgency prefix ("Immediate action required:") on the emergency tier.

| Tier | Token | Header example |
|---|---|---|
| Tip / worth knowing | `--primary` (clay), quiet left-border style, no header bar | — |
| Support / non-urgent | `--success` (laurel) | "Talk to someone now if:" |
| Caution | `--signal` (amber) | "Check with a clinician first if:" |
| Emergency | `--destructive` | "Call 911 or go to the ER now if:" |

Cards appear **inline at the point of relevance** (NHS codeine-page pattern), not only at page top. The existing quiet `info` style remains for plain notes.

### Help now (replaces `CrisisButton.tsx`)

Header-resident, destructive fill, ≥44px target, label "Help now", present on every page including mobile sticky header. Links to the crisis fast-path. Not dismissible; never overlaps content. Delete the floating pill.

### Status banner

Keep the branch's light-amber banner; enforce one line + status dot on desktop, two lines max on mobile, dismissible. It is ambient status — alarm styling stays reserved for the emergency tier.

### Buttons

Branch already has solid-clay primary and outlined ghost pills — keep. Special fills: Help-now (destructive) and crisis-page `tel:` button. Min target 44px; 52px on the crisis page.

### Logo — the Lift Cup (brand rule, non-negotiable)

The mark is a coffee cup with an up-arrow rising out of it (`brand/logo/`, component: `src/components/Logo.astro`). Color mapping is fixed: **cup stroked in `--foreground`, arrow in `--primary`** — never recolored outside that mapping, never stretched, rotated, gradiented, or shadowed. The mono variant (`lift-cup-mono.svg`, `currentColor`) is for single-color contexts. Header treatment per `Logo.astro`: mark in a 28%-radius accent-tinted container with ~12% padding, wordmark in Newsreader with the "7" in `--primary` and ".org" small in `--muted-foreground`. Favicons/app icons ship in `brand/favicons-stone/` (full per-theme sets live in `public/favicons/`). Written guide: `brand/style-guide.md`; rendered: https://quitting7oh.org/brand.

### Everything else

Sidebar (guide-index card + grouped nav), TOC rail, breadcrumbs, prev/next, meeting card, search pill + ⌘K modal: keep the branch's implementations, restyled only where the blueprints (03) call for it. Icons remain Lucide, 18px/2px stroke (22px in crisis contexts). Pagefind modal gets token styling.

## Accessibility checklist (ship-blocking — WCAG 2.2 AA, verified per phase with axe)

- Contrast AA in both themes, including text on tier-colored header bars, clay links on dark, and muted metadata — checked programmatically.
- Visible focus everywhere (branch's 3px ring — keep, both themes); logical tab order; no keyboard traps.
- Drawer and ⌘K search modal: focus moves in on open, trapped while open, `Escape` closes, focus returns to trigger.
- Touch targets ≥ 44px (crisis page ≥ 52px), ≥8px between adjacent targets, visible pressed states, no hover-only affordances, no long-press/drag/double-tap anywhere (tremor).
- `prefers-reduced-motion` gates all motion (`scroll-behavior: smooth`, pulse dots, transitions).
- Landmarks, one `h1`, no skipped heading levels, skip-link first in DOM, `aria-current` on active nav.
- sr-only urgency prefixes on emergency care-cards; `aria-label` on icon-only buttons; countdowns `aria-live="polite"`; decorative icons `aria-hidden`; criteria never color-only.
- 200% zoom and 320px reflow without loss; survives the WCAG text-spacing override without clipping. Left-aligned text throughout.
- Mobile correctness: `100dvh` for drawers/modals, `env(safe-area-inset-*)` on sticky chrome, `inputmode` on calculator fields.
