# 01 — Design Brief (Rev 2 — based on `experiment/chatgpt-redesign`)

## Who this site is for

Three readers, in descending order of design priority:

1. **Someone in acute withdrawal.** Anxious, possibly shaking, on a phone, maybe at 3am with the brightness down. Working memory and patience are severely reduced — stress research shows users in crisis rely on fast intuitive judgment, not careful reading (Smashing Magazine, "Designing for Stress and Emergency," Nov 2025). Every decision gets tested against this person first.
2. **Someone planning a quit or mid-taper.** Long careful reading, comparisons, returning over weeks. Needs comfortable long-form reading, good search, stable wayfinding.
3. **A loved one or a clinician.** Skimming for credibility. Visual craft is a trust signal — and here, trust is a safety feature.

## Direction

**Calm & trustworthy + modern docs polish**, now expressed through the branch's established **Field Guide** language: quiet warm paper, burnt-clay accent, Newsreader editorial serif for display, Atkinson Hyperlegible Next for body, field-note eyebrow labels, numbered editorial sections. Rev 2 does not re-litigate that language — it completes it.

## Audit of the branch (prod build, 2026-08-20 — screenshots in `screenshots/chatgpt-branch/`)

### What the field-guide pass gets right — build on it, don't undo it

- **Typography.** Atkinson Hyperlegible Next for body is an outstanding accessibility choice (built for character disambiguation); Newsreader gives the editorial warmth. The pairing is the site's new identity.
- **The palette.** Burnt clay (`--primary`), warm paper, plus true semantic tokens: `--signal` (amber), `--success` (laurel green), `--destructive` (red). Cohesive in both themes; dark mode is warm-toned, not neutral black.
- **Editorial structure.** Centered "START HERE / Quitting 7-OH: next steps" hero with a big "I'm in withdrawal now" primary CTA, prominent search, numbered 01/02/03 topic list, section rules, "FIELD NOTE" eyebrows. Restrained and distinctive.
- **Simplified meeting card.** LIVE NOW chip + one Join button — a huge improvement over main's nested boxes.
- **Header actions.** "Find a meeting" pill with live dot, Discord pill, "Search the guide." Good hierarchy.
- **Craft details.** 3px focus-visible ring, `scroll-padding-top`, selection tint, radius scale (0.35/0.55/0.8/1.1rem), sidebar "Guide index" card, weight-430 body.

### What rev 2 adds — the actual work

1. **An urgency grammar that can carry emergencies.** The branch's `Callout.tsx` has three tiers (info/warning/medical) but renders all of them as quiet 14px tint-washes with muted-foreground text. "Call 911 / go to the ER now if:" content cannot live in a whisper. Adopt the NHS care-card anatomy — colored header bar, action-oriented heading ending in "…if:", bulleted criteria, sr-only urgency prefix — mapped onto the branch's own tokens: **support tier = `--success` (laurel), caution = `--signal` (amber), emergency = `--destructive`**. Keep the current quiet style for the plain "Note" tier. See `mockups/mockup-doc-page.html`.
2. **Replace the floating Crisis pill.** Still present on the branch, still overlapping the sidebar/meeting card on every viewport, still dismissible. Replace with a persistent **Help now** button in the header (destructive fill, ≥44px, never dismissed, same position on every page).
3. **A true crisis fast-path.** The branch's "I'm in withdrawal now" CTA leads to the long guide in full chrome. Add the stripped-down layout — minimal header, one numbered 10–30-second step at a time, 52px action buttons, ER card last — per `mockups/mockup-crisis-page.html`, applied to the existing URL.
4. **Homepage "Right now" affordances.** Keep the branch's centered hero; beneath the search, give the crisis path, Discord #sos, and next-meeting line a compact "Right now, if you need it" treatment (see `mockup-home.html` for the component; it can sit in the branch's layout without replacing the hero).
5. **Reading comfort.** Branch body is 16px/1.6. For article content, go to 17px mobile / 18px desktop within a 68–72ch measure, and let callout body text be full-size and full-contrast — never `muted-foreground` for safety content. More top-margin before h2s.
6. **Dark mode, one nudge.** Branch dark bg is `hsl(22 14% 8%)` (≈`#181310`) — warm-toned (good) but deep enough to risk halation with 92%-lightness text. Lift surfaces ~2–3 points (see mockup dark tokens) and check AA contrast on clay-on-dark links.
7. **Banner discipline.** The light amber ban banner is good; keep it to a single line with a status dot on desktop and compress harder on mobile (currently 3 lines before the fold).

## Design principles (unchanged from rev 1)

1. **The 3am test.** Usable while shaking, in the dark, on a phone at 10% battery — or it loses.
2. **Calm is earned by restraint.** Clay does accent work; signal/success/destructive appear only with their meanings.
3. **Urgency is a system, not a decoration.** Three tiers, same anatomy everywhere, learnable.
4. **Trust through craft.** Aligned, consistent, deliberate.
5. **The content is the interface.** Chrome quiet, content leads.
6. **Never break a URL.**
7. **Both themes are first-class.**

## Success criteria

- From any page, a visitor in withdrawal reaches a concrete "do this now" action in **two taps or fewer**.
- Lighthouse accessibility ≥ 95 on the five key templates; WCAG 2.2 AA in both themes; touch targets ≥ 44px.
- All existing URLs still resolve with equivalent content.
- The branch's field-guide character is *more* itself afterward — a reader should feel the same site, finished.
