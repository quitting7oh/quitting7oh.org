# 00 — Prompt for ChatGPT Codex

Paste everything below the line into Codex, opened in the quitting7oh.org repo with the `experiment/chatgpt-redesign` branch checked out and this package folder available (adjust the path if you placed it elsewhere). This prompt is self-contained — Codex should treat the rules inside it as binding for the whole session.

---

You are finishing the redesign of quitting7oh.org — a community harm-reduction reference for people quitting 7-OH/kratom-derived opioids. Many readers are in acute withdrawal, on phones, at night, possibly with tremors and poor concentration. **This site is mobile-first and accessibility-first; treat both as correctness, not polish.**

Work from the design package in `design/redesign-package/`. Before writing any code:

1. Read `README.md`, `01-design-brief.md`, `02-design-system.md`, `03-page-blueprints.md`, and `04-implementation-paths.md` in full. Skim `05-inspiration-and-resources.md` and consult exemplars as you build.
2. Look at the images in `screenshots/chatgpt-branch/` (this branch as built — your base), `screenshots/redesign-mockups/` (the target), and `screenshots/main-baseline/` (history). Open the three files in `mockups/` — their `:root` CSS blocks are the target tokens in plain hex, light and dark.
3. The base design system already on this branch (`src/styles/global.css` — fonts, burnt-clay palette, semantic signal/success/destructive tokens) is the foundation. Extend it; do not replace it.
4. Brand sources are authoritative over this package where they conflict: `docs/brand/style-guide.md` (copy in `design/redesign-package/brand/`), the rendered guide at https://quitting7oh.org/brand, and `src/components/Logo.astro`. The logo is the **Lift Cup** — cup stroked in `--foreground`, arrow in `--primary`; never recolor outside that mapping, stretch, rotate, or add gradients/shadows. Reuse `Logo.astro`.

## Binding rules for this session (this repo deploys to production on push)

- **Never run `git push`. Never commit without the owner explicitly approving that specific commit.** Default: edit the working tree, build, show results, stop and wait. `git push` triggers a Cloudflare Pages production deploy seen immediately by readers in withdrawal.
- **Never touch `main`.** Stay on `experiment/chatgpt-redesign` or a branch cut from it.
- **No URL may change or break.** Build first and inventory the routes in `dist/`; after each phase rebuild and diff the inventory — zero regressions.
- Content is preserved; this is design work. Microcopy edits only where the blueprints call for them.
- External links in hand-written JSX/Astro need `target="_blank" rel="noopener noreferrer"` explicitly; markdown gets it automatically from the `rehypeExternalLinks` plugin — never add it manually in markdown.
- Leave unrelated working-tree changes alone (docket scripts in `package.json`, `.claude/`).
- Both themes ship together on every component; dark mode uses the warm-dark palette — no near-black backgrounds, no pure-white text.
- The urgency triad — laurel `--success`, amber `--signal`, red `--destructive` — appears only with its semantic meaning, sitewide.
- Toolchain: Node ≥ 22.16, `npm ci`, `npm run build` (runs Pagefind + changelog sync), `npm run lint:md` stays clean if markdown is touched.

## Mobile mandate — design at 390px first

Most readers in crisis are on a phone. For **every** component and template in this work:

- **Build and review the 390px layout before the 1440px one.** Also check 360px and 320px (no horizontal scroll at 320px, ever) and 768px. Screenshot mobile first in every phase report.
- **Header on mobile:** Help now stays visible at all times in the sticky header — it never collapses into a menu. Banner compresses to ≤2 lines. Search collapses to an icon opening a full-screen modal. Nav goes into the existing drawer.
- **Touch:** targets ≥44×44px (≥52px on the crisis page), ≥8px between adjacent targets, visible `:active`/pressed states, no hover-only affordances (the TOC copy-link, card hovers, etc. all need touch equivalents).
- **Thumb reach:** on the crisis page, primary actions sit in the lower two-thirds of the first viewport where a thumb lands; nothing critical hides behind the fold without a visible cue.
- **Viewport correctness:** use `100dvh` (not `100vh`) for drawers/modals; respect `env(safe-area-inset-*)` for the sticky header and any bottom-anchored UI; `-webkit-text-size-adjust: 100%` stays.
- **Inputs:** calculators get `inputmode="decimal"`/`"numeric"`, sensible `autocomplete`, and 44px+ steppers — no tiny spin buttons.
- **Performance is a mobile feature:** audit Astro islands — `client:load` only for immediately-interactive components, `client:idle`/`client:visible` otherwise; no new JS dependencies for things CSS can do; fonts stay self-hosted subsets. Run Lighthouse with the **mobile** preset and throttling on the five key templates: Performance ≥90, LCP < 2.5s.
- Long tables (dosing, meetings) get an explicit mobile treatment — stacked rows or horizontal scroll with a visible affordance, chosen per table, never accidental overflow.

## Accessibility mandate — WCAG 2.2 AA, verified, not assumed

This audience skews toward tremor (motor), brain fog (cognitive), and 3am low-vision conditions. Accessibility failures here have real consequences.

- **Semantics:** correct landmarks (`header/nav/main/aside/footer`), one `h1` per page, no skipped heading levels, skip-to-content link first in DOM, `aria-current="page"` on active nav, breadcrumbs in a labeled `nav`.
- **Keyboard:** every interaction operable by keyboard alone; logical tab order; the branch's 3px focus ring on every focusable element in both themes; no traps. Drawer and ⌘K search modal: focus moves in on open, is trapped while open, `Escape` closes, focus returns to the trigger on close.
- **Screen readers:** care-cards announce urgency (sr-only "Immediate action required:" prefix on the emergency tier); icon-only buttons have `aria-label`s; the live meeting countdown uses `aria-live="polite"` (never `assertive`); decorative icons `aria-hidden`. Do a VoiceOver or NVDA pass on the crisis page, the withdrawal guide, and the homepage: reading order sane, all actions reachable and named.
- **Contrast:** AA (4.5:1 text, 3:1 large/UI) in **both** themes, including text on tier-colored header bars, clay links on dark, and muted metadata. Check programmatically, not by eye.
- **Zoom & reflow:** 200% zoom and 320px-wide reflow with no loss of content or function; survives the WCAG text-spacing override (line-height 1.5×, paragraph 2×, letter 0.12×, word 0.16×) without clipping.
- **Motion & cognition:** all animation (smooth scroll, pulse dots, transitions) gated behind `prefers-reduced-motion`; no auto-playing movement; plain language preserved; one action per step on the crisis page; nothing color-only (tier icons + worded headings carry the meaning).
- **No timing or precision demands:** no long-press, drag, or double-tap requirements anywhere (tremor).
- **Verification, each phase:** axe (or Lighthouse a11y) run with **zero critical/serious issues**; Lighthouse accessibility ≥95 (aim 100) on the five key templates; one keyboard-only walkthrough of any flow the phase touched. The full checklist in `02-design-system.md` is ship-blocking.

## Phases — one at a time, verify, then continue

1. **Token nudges:** lift dark surfaces ~2–3 lightness points per `02-design-system.md`; fix any AA misses (run a full-palette contrast audit and report it).
2. **Help now:** persistent destructive header button on every page, mobile included; delete the floating `CrisisButton` overlay.
3. **Care-cards:** extend `Callout.tsx` with the NHS-style support/caution/emergency anatomy (colored header bar, "…if:" heading, full-size body text, sr-only urgency prefix); upgrade the withdrawal guide's ER content first.
4. **Article reading pass:** body 18px desktop/17 mobile in a 68–72ch measure, h2 spacing, Do/Don't component, prev/next; mobile TOC as a collapsible "On this page" above content.
5. **Mobile chrome pass:** banner compression, drawer nav focus management, search modal behavior, safe-area/`dvh` audit, touch-target sweep across all shared components.
6. **Homepage:** "Right now, if you need it" strip (merge the meeting card into it), category directory section, footer ethos line — 390px layout designed first.
7. **Crisis page:** stripped `CrisisLayout` on the existing withdrawal-help URL per `mockup-crisis-page.html` — this page is designed *for* a phone; desktop is the adaptation.
8. **Remaining templates:** category index, compound fact panel, meetings hero card, 404, Pagefind modal styling (including its keyboard/focus behavior).
9. **QA:** full accessibility checklist from 02, axe zero critical/serious sitewide, Lighthouse (mobile preset) ≥90 perf / ≥95 a11y on the five key templates, URL diff clean, screenshots at 320/390/768/1440 in both themes, keyboard-only and screen-reader walkthroughs of homepage → crisis page → guide page.

After each phase: build, screenshot affected templates (mobile first, both themes), run axe on them, compare to the mockups, summarize what changed and what the audits found, and **wait for the owner before any commit**.

The bar: the field-guide design should feel *finished*, not replaced — and a stranger in withdrawal at 3am, on a cheap phone, using one shaky thumb — possibly with a screen reader — reaches a concrete next action in two taps.
