# quitting7oh.org Redesign Package — Revision 2

A self-contained handoff package for redesigning [quitting7oh.org](https://quitting7oh.org) with a coding agent — written for **ChatGPT Codex** (primary, per the owner's plan) or **Claude Code**, with a dedicated prompt file for each.

**Revision 2 (2026-08-20): the base is now the `experiment/chatgpt-redesign` branch**, not `main`. That branch is a substantive redesign already — the "Field Guide" system: Newsreader display serif + Atkinson Hyperlegible Next body, burnt-clay palette, signal/success/destructive semantic tokens, editorial layout with numbered sections. Rev 2 treats that work as the foundation and layers this package's structural moves on top of it, in its visual language.

## How to use

1. Put this folder in the repo (suggested: `design/redesign-package/`).
2. Check out `experiment/chatgpt-redesign`. **Work stays on that branch (or a branch cut from it). Nothing is committed or pushed without the owner's explicit approval.**
3. ChatGPT Codex: paste `00-CODEX-PROMPT.md`. Claude Code: paste `00-CLAUDE-CODE-PROMPT.md`. Both point at the same docs.

## What's inside

| Path | What it is |
|---|---|
| `00-CODEX-PROMPT.md` | Ready-to-paste instructions for ChatGPT Codex — fully self-contained, repo rules inlined |
| `00-CLAUDE-CODE-PROMPT.md` | Same plan phrased for Claude Code (which also reads the repo's CLAUDE.md) |
| `01-design-brief.md` | Audience, direction, audit of the branch (what the field-guide pass nails, what rev 2 adds) |
| `02-design-system.md` | The branch's actual tokens + rev-2 extensions (urgency care-cards, Help-now, reading scale) |
| `03-page-blueprints.md` | Per-template layout specs building on the branch's layouts |
| `04-implementation-paths.md` | The work plan on the branch, agent-specific notes (AGENTS.md for Codex), and the framework research for the record |
| `05-inspiration-and-resources.md` | Annotated exemplars (NHS, Linear, Stripe…), crisis-UX and dark-mode research, tools |
| `mockups/*.html` | Three working mockups (homepage, guide page, crisis page) **re-themed to the branch's field-guide palette and fonts**, using the real Lift Cup logo. Their `:root` CSS blocks are the rev-2 tokens, light + dark. |
| `brand/` | The site's own brand assets, copied from the repo: `style-guide.md` (written guide), `agent-context.md` (agent-facing brand rules), `logo/` (Lift Cup SVGs — themed + mono), `favicons-stone/` (favicon/app-icon set). The rendered guide lives at https://quitting7oh.org/brand. |
| `screenshots/main-baseline/` | The original site (main), for history |
| `screenshots/chatgpt-branch/` | The `experiment/chatgpt-redesign` branch as built (prod build, desktop/mobile/dark) |
| `screenshots/redesign-mockups/` | The rev-2 targets rendered desktop/mobile, light/dark |

## The one-paragraph summary

The ChatGPT branch already moved the site to a warm, editorial "field guide" — keep its palette, fonts, and voice. What rev 2 adds is the safety-and-structure layer: NHS-style three-tier urgency care-cards (the branch's callouts are too quiet for "go to the ER if:" content), a persistent header **Help now** button replacing the floating dismissible Crisis pill, a stripped-down one-step-at-a-time crisis page, a "Right now, if you need it" fast-path on the homepage, larger reading text in a 68–72ch measure, and a slightly lifted warm dark mode. **Hard constraints: existing URLs must not change, and nothing gets committed or pushed without the owner's say-so.**
