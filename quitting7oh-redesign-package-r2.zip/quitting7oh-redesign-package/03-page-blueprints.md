# 03 — Page Blueprints (Rev 2)

Layout specs per template, **building on the branch's existing layouts** — the branch screenshots (`screenshots/chatgpt-branch/`) show the base, the mockup screenshots show the target components. Where a branch layout already works, the blueprint says "keep."

## Homepage (`/`)

**Keep the branch's centered editorial hero** — eyebrow, "Quitting 7-OH: next steps", lede, "I'm in withdrawal now" primary + "Compare quitting options" ghost, search bar, meeting card, numbered 01/02/03 topics. Changes:

1. **Insert a "Right now, if you need it" strip** between the search bar and the meeting section — the three-row component from `mockup-home.html` (In active withdrawal → / Talk to someone who gets it (Discord #sos) → / Next live meeting →), full hero width, single card, one hairline per row. The meeting card below can then drop to a single row or merge into this strip (owner's call; merging is cleaner — the strip's third row IS the next meeting).
2. **Header:** add **Help now** (destructive) at the far right; remove the floating Crisis pill sitewide. Keep Find-a-meeting/Discord/Search pills, collapsing gracefully on mobile (icons before disappearance; Help now never disappears).
3. **Banner:** one line + status dot desktop, ≤2 lines mobile.
4. Below the numbered topics, add the **full category directory** (2-col hairline list, all 10 categories with one-line description + page count — from `mockup-home.html`) so everything is two clicks away, and the footer ethos line: "No accounts. No tracking. No money. Just people who made it through."

## Guide/article page (`/[category]/[slug]`)

Branch already has the right frame (sidebar + article + TOC rail, field-note eyebrow, section rules). Changes per `mockup-doc-page.html`:

```
│ QUICK LINKS │ crumbs › …                    │ ON THIS PAGE  │
│ ▎active     │ EYEBROW · FIELD NOTE          │ ▎active item  │
│  …          │ H1 Newsreader 40              │  …            │
│ START HERE  │ lede 20 muted · meta row      │               │
│  …          │ body 18px, 68–72ch            │               │
│             │ ┌─🟢 laurel header bar──────┐ │               │
│             │ │ Talk to someone now if:   │ │               │
│             │ └─ criteria, full size ─────┘ │               │
│             │ ## section (40px top)         │               │
│             │ clay tip aside · Do/Don't 2up │               │
│             │ ┌─🔴 red header bar─────────┐ │               │
│             │ │ Call 911 / ER now if:     │ │               │
│             │ └───────────────────────────┘ │               │
│             │ [← Prev]            [Next →]  │               │
```

- Care-cards (02) replace quiet callouts for support/caution/emergency content, placed inline at point of relevance.
- Article body 18px desktop / 17 mobile; callout text full-size, never muted.
- Add the **Do/Don't** two-up component (laurel ✓ / destructive ✕).
- Keep branch TOC tracking, copy-link button, breadcrumbs; add prev/next footer cards if absent.
- Mobile: sidebar → drawer, TOC → collapsible above content, `wide` variant unchanged for calculators.

## Crisis page — the existing withdrawal-help URL

Per `mockup-crisis-page.html`, applied **to the existing URL** (no new route at its expense):

Minimal chrome (logo + "Full site →" — no sidebar, TOC, banner, or search). 680px column. "You're going to be okay." in Newsreader 44px. Four numbered step-cards, each one 10–30-second action: (1) tell someone — Discord #sos 52px button + next-meeting ghost; (2) water + hot shower; (3) handle the worst symptom — quick-links; (4) options from here. Centered reassurance line. Emergency care-card last with criteria + `tel:` 988 button. The deep reference content (mechanism, hour-by-hour, ER expectations) lives below the steps or one link away — steps first, always.

## Category index (`/[category]`)

Keep the branch's restyled index; ensure: category name in Newsreader + one-line description + page count header, single-level row cards (title 16/600, description 14, updated date faint), pinned pages first with a subtle clay chip. No nested boxes.

## Compound profile (`/compounds/[slug]`)

Article layout plus a **fact panel** at top (raised card, 2-col definition list: class, receptor activity, legal status, common forms, withdrawal profile) — NHS "key facts first." Legal status may take a signal-amber chip; destructive red only for emergency-relevant facts.

## Meetings page

Keep branch functionality and its LIVE NOW chip; next meeting as the single hero card (clay border, countdown, one Join button), schedule table below, timezone note faint.

## Global

- Skip-link first in DOM; landmarks; focus ring (branch's 3px) everywhere.
- Footer sitewide: ethos line + Discord/Reddit/GitHub/Disclaimer + "Edit on GitHub" on articles.
- Pagefind/⌘K modal styled to field-guide tokens.
- 404: calm, search box, quick links.
