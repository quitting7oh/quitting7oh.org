# 04 — Implementation Plan (Rev 2)

## The base

All work happens on **`experiment/chatgpt-redesign`** (or a branch cut from it) in the existing custom Astro stack — Astro 5 + Tailwind 4 + MDX collections + Pagefind + Radix + Lucide. The branch has already done the re-theming (fonts, palette, editorial layout); rev 2 is component and template work inside that system. No framework migration.

Note for agents: the working tree may carry unrelated uncommitted changes (docket-analysis scripts in `package.json`, `.claude/` settings). Leave them alone.

## Ground rules (both agents, non-negotiable)

1. **No commits and no pushes without the owner's explicit, per-instance approval.** `git push` deploys to production via CF Pages — readers in withdrawal see it live. Default behavior: make changes in the working tree, build, show results, stop.
2. **Never touch `main`.**
3. **No URL may change or break.** Build the site before starting and inventory `dist/` routes; re-inventory after each phase; zero diffs.
4. Content is preserved — this is design work. Microcopy edits only where blueprints call for them; flag anything larger.
5. External links carry `target="_blank" rel="noopener noreferrer"` (markdown gets it from the `rehypeExternalLinks` plugin — don't add manually there; hand-written JSX/Astro anchors need it explicitly).
6. Both themes ship together; the urgency triad (laurel/signal/destructive) is used only semantically.
7. WCAG 2.2 AA per the checklist in `02-design-system.md`.

## Work plan — phases, each independently verifiable

1. **Token nudges.** Dark-surface lift + a full-palette AA contrast audit and fixes in `src/styles/global.css` (see 02). Smallest phase; do it first to bed in the review loop.
2. **Help now.** Header button on every page — never collapsed or hidden on mobile; delete the floating `CrisisButton` overlay.
3. **Care-card system.** Extend `Callout.tsx` (or add `CareCard.tsx`) with the support/caution/emergency anatomy from 02, including the sr-only urgency prefix; sweep content for callouts that should upgrade tiers (the withdrawal guide's ER section first).
4. **Article reading pass.** Body 18/17, 68–72ch measure, full-size callout text, h2 spacing, Do/Don't component, prev/next; mobile TOC as a collapsible "On this page" above content.
5. **Mobile chrome pass.** Banner compression (≤2 lines), drawer-nav focus management, full-screen search modal behavior, `dvh`/safe-area audit, and a touch-target sweep (≥44px, ≥8px separation, pressed states) across shared components.
6. **Homepage.** "Right now" strip + meeting-card merge, directory section, footer ethos line — 390px layout designed first.
7. **Crisis page.** `CrisisLayout.astro` applied to the existing withdrawal-help URL per blueprint — designed for a phone; desktop is the adaptation.
8. **Remaining templates.** Category index polish, compound fact panel, meetings hero card, 404, Pagefind modal styling (including keyboard/focus behavior).
9. **QA.** Full accessibility checklist from 02, axe zero critical/serious sitewide, Lighthouse **mobile preset** ≥90 performance / ≥95 accessibility on the five key templates, URL inventory diff clean, screenshots at 320/390/768/1440 × light/dark, keyboard-only and screen-reader walkthroughs of homepage → crisis page → guide page.

After each phase: `npm run build`, screenshot affected templates (**mobile first**, both themes), run axe on them, compare against `screenshots/redesign-mockups/`, summarize the diff and audit results for the owner, and **wait before committing anything**.

## Agent-specific notes

**ChatGPT Codex (primary):**
- Codex does not read `CLAUDE.md`. The repo's durable rules are restated in `00-CODEX-PROMPT.md`; treat them as binding. If the owner wants them persistent for future Codex sessions, copy the rules into an `AGENTS.md` at repo root (Codex reads that convention) — ask first, since it's a new file.
- Run `npm ci` then `npm run build` (build also runs Pagefind and the changelog sync; Node ≥ 22.16).
- `npm run lint:md` must stay clean if any markdown is touched.

**Claude Code:**
- Reads `CLAUDE.md` automatically — its push-approval and external-link rules apply as written there.
- Same phases, same verification loop.

## For the record: framework research (Aug 2026, from rev 1)

The stay-custom decision was researched before the branch existed and holds even more strongly now that the theme layer is bespoke: **Starlight 0.41.x** (pre-1.0, breaking minors ~2×/year; Pagefind/a11y built in — but would fight every layout in this package), **VitePress 1.6.4** (excellent `rewrites`, but Vue — discards the React component investment), Docusaurus 3.10 / Nextra 4 / Fumadocs 16 (heavier runtimes, wrong hosting models), MkDocs Material 9.7 (Python toolchain, Material identity), Mintlify (closed hosted SaaS — wrong for a no-tracking community project), Rspress 2.0 (young). Adopt the 2026 llms.txt / markdown-endpoint convention at some point so AI assistants cite the site accurately — small Astro integration, any time.
