# 00 — Prompt for Claude Code

Paste everything below the line into Claude Code, opened in the quitting7oh.org repo with the `experiment/chatgpt-redesign` branch checked out and this package folder available (adjust the path if you placed it elsewhere).

---

Finish the redesign of this site following the package in `design/redesign-package/`. Many readers are in acute withdrawal, on phones, at night, possibly with tremors and poor concentration. **Mobile-first and accessibility-first are correctness requirements here, not polish.**

Before writing any code:

1. Read `README.md`, then `01-design-brief.md`, `02-design-system.md`, `03-page-blueprints.md`, and `04-implementation-paths.md` in full. Skim `05-inspiration-and-resources.md` and fetch exemplars when relevant.
2. Look at the images in `screenshots/chatgpt-branch/` (this branch as built — your base), `screenshots/redesign-mockups/` (the target), and `screenshots/main-baseline/` (history). Open the three files in `mockups/` — their `:root` CSS blocks are the target tokens, light and dark.
3. Read the repo's `CLAUDE.md` and follow it — especially the push-approval rule: **never commit without per-commit approval, never push without explicit approval for that push** (pushes deploy to production for readers in withdrawal). Additionally: **never touch `main`** — stay on `experiment/chatgpt-redesign` or a branch cut from it, and leave unrelated working-tree changes alone (docket scripts in `package.json`, `.claude/`).

The base design system already on this branch (`src/styles/global.css` — Newsreader/Atkinson fonts, burnt-clay palette, signal/success/destructive tokens) is the foundation. Extend it; do not replace it. Brand sources are authoritative over this package where they conflict: `docs/brand/style-guide.md` (copy in `design/redesign-package/brand/`), https://quitting7oh.org/brand, and `src/components/Logo.astro`. The logo is the **Lift Cup** — cup stroked in `--foreground`, arrow in `--primary`; never recolor outside that mapping, stretch, rotate, or add gradients/shadows.

## Hard constraints

- **No URL may change or break.** Inventory `dist/` routes before starting; rebuild and diff after each phase; zero regressions.
- Content stays intact; microcopy edits only where blueprints call for them.
- Both themes ship together; warm dark palette — no near-black, no pure-white text.
- The urgency triad (laurel/signal/destructive) appears only with its semantic meaning.

## Mobile mandate — design at 390px first

- Build and review every component at **390px before 1440px**; also check 360px, 320px (no horizontal scroll, ever), and 768px. Screenshot mobile first in every phase report.
- Header on mobile: **Help now never collapses or hides**; banner ≤2 lines; search becomes an icon → full-screen modal; nav uses the existing drawer.
- Touch: targets ≥44×44px (≥52px on the crisis page), ≥8px between targets, visible pressed states, no hover-only affordances.
- Thumb reach on the crisis page: primary actions in the lower two-thirds of the first viewport.
- `100dvh` not `100vh` for drawers/modals; `env(safe-area-inset-*)` respected; calculators get `inputmode` and 44px+ steppers.
- Performance is a mobile feature: audit island hydration (`client:load` only when immediately interactive), no new JS for CSS-solvable problems; Lighthouse **mobile preset** ≥90 performance, LCP < 2.5s on the five key templates.
- Dosing/meeting tables get an explicit mobile treatment (stacked or scrollable with a visible affordance) — never accidental overflow.

## Accessibility mandate — WCAG 2.2 AA, verified, not assumed

- Semantics: landmarks, one `h1`, no skipped heading levels, skip-link first in DOM, `aria-current` on active nav.
- Keyboard: everything operable, logical order, the 3px focus ring everywhere in both themes, no traps; drawer and ⌘K modal trap focus while open, close on `Escape`, return focus on close.
- Screen readers: sr-only "Immediate action required:" on emergency care-cards; `aria-label` on icon-only buttons; countdowns `aria-live="polite"`; decorative icons hidden. Do a VoiceOver/NVDA pass on homepage, crisis page, and the withdrawal guide.
- Contrast: AA in **both** themes (incl. tier header bars, clay-on-dark links, muted metadata), checked programmatically.
- Zoom/reflow: 200% zoom and 320px reflow lossless; survives the WCAG text-spacing override without clipping.
- Motion/cognition: everything gated by `prefers-reduced-motion`; nothing color-only; no long-press/drag/double-tap anywhere (tremor).
- Per phase: axe with **zero critical/serious**, Lighthouse a11y ≥95 (aim 100), one keyboard-only walkthrough of touched flows. The checklist in `02-design-system.md` is ship-blocking.

## Phases — one at a time, verify, then continue

1. **Token nudges:** dark-surface lift + full-palette AA contrast audit and fixes.
2. **Help now:** persistent destructive header button everywhere, mobile included; delete the floating `CrisisButton`.
3. **Care-cards:** extend `Callout.tsx` with support/caution/emergency anatomy (header bar, "…if:" heading, full-size text, sr-only prefix); upgrade the withdrawal guide's ER content first.
4. **Article reading pass:** 18/17px body, 68–72ch, h2 spacing, Do/Don't, prev/next; mobile TOC as collapsible "On this page" above content.
5. **Mobile chrome pass:** banner compression, drawer focus management, search modal behavior, safe-area/`dvh` audit, touch-target sweep.
6. **Homepage:** "Right now" strip (absorb the meeting card), directory section, ethos footer — 390px layout designed first.
7. **Crisis page:** stripped `CrisisLayout` on the existing withdrawal-help URL — designed *for* a phone; desktop is the adaptation.
8. **Remaining templates:** category index, compound fact panel, meetings hero, 404, Pagefind modal (incl. keyboard/focus behavior).
9. **QA:** full a11y checklist, axe clean sitewide, Lighthouse mobile ≥90 perf / ≥95 a11y on five key templates, URL diff clean, 320/390/768/1440 × light/dark screenshots, keyboard-only and screen-reader walkthroughs of homepage → crisis → guide.

After each phase: build, screenshot affected templates (mobile first, both themes), run axe, self-review against the mockups, summarize changes and audit results — and stop before committing.

The bar: the field-guide design should feel *finished*, not replaced — and a stranger in withdrawal at 3am, on a cheap phone, with one shaky thumb — possibly using a screen reader — reaches a concrete next action in two taps.
