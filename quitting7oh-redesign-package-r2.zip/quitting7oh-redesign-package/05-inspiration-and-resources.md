# 05 — Inspiration & Resources (Rev 2)

Rev-2 note: the branch has already adopted several rev-1 recommendations — Atkinson Hyperlegible Next as body font, semantic urgency tokens, a warm dark theme. The exemplars below remain the reference points for what's still to build (care-cards, crisis page, Help-now) and for calibration.

Annotated links, verified Aug 2026. Claude Code: when working on a specific component, fetch the relevant exemplar and look at how it solves the problem before writing code. Sandbox screenshots of third-party sites weren't possible from this environment, so fetch/screenshot these locally as needed — each entry says exactly what to look at.

## Health-information exemplars (the "calm & trustworthy" pole)

- **NHS medicine page — codeine** · https://www.nhs.uk/medicines/codeine/
  The single most relevant page on the internet for this redesign: a drug page for anxious readers. Study: contents list up top, urgent-advice boxes inline at point of relevance, Do/Don't lists, 19px body, plain-language "action + if:" headings.
- **NHS care cards pattern** · https://service-manual.nhs.uk/design-system/patterns/help-users-decide-when-and-where-to-get-care
  All three urgency tiers rendered with anatomy notes. Our callout spec is derived from this.
- **NHS design system** · https://service-manual.nhs.uk/design-system (typography: /styles/typography · colour: /styles/colour · components: /components) · code: https://github.com/nhsuk/nhsuk-frontend
- **NHS content guide** · https://service-manual.nhs.uk/content — writing for stressed/low-literacy readers; useful when touching microcopy.
- **GOV.UK design system** · https://design-system.service.gov.uk/ — warning text, notification banner, details/accordion; deepest research base.
- **ODPHP Health Literacy Online** · https://odphp.health.gov/healthliteracyonline — US federal guide to health web design: action-first, chunking, 6th–8th-grade reading level.
- **DanceSafe** · https://dancesafe.org/drug-information/ — harm-reduction tone done right; card grid of substance profiles (model for /compounds index). Avoid its cluttered long-article hierarchy.
- **Never Use Alone** · https://neverusealone.com/ — one giant tap-to-call number as the primary element; the pattern behind our crisis-page phone buttons. 988 sites (https://988lifeline.org/) repeat call/text/chat CTAs in header+footer sitewide.
- **Headspace** · https://www.headspace.com/ — the warmth calibration: warm neutrals, one friendly accent, huge whitespace. Steal temperature, not illustration style.

## Docs-polish exemplars (the "modern docs" pole)

- **Linear docs** · https://linear.app/docs — restraint benchmark; quiet sidebar, almost no chrome. Closest docs analog of "calm."
- **Stripe docs** · https://docs.stripe.com/ — IA + search benchmark (⌘K, progressive disclosure).
- **Tailwind docs** · https://tailwindcss.com/docs — sticky sidebar + right TOC + dark mode on a content page; nearest structural cousin of our doc template.
- **Astro docs (Starlight)** · https://docs.astro.build/ — aside/callout styling, mobile TOC handling.
- **Resend docs** · https://resend.com/docs — dark-mode polish reference.
- **Clerk docs** · https://clerk.com/docs — tabs/callouts, dark mode.

## Pattern & accessibility reading

- Smashing Magazine, **Designing for Stress and Emergency** (Nov 2025) · https://www.smashingmagazine.com/2025/11/designing-for-stress-emergency/ — the crisis-page rationale: 10–30-second steps, no distractions, highest-impact action first.
- Smashing Magazine, **Inclusive Dark Mode** (Apr 2025) · https://www.smashingmagazine.com/2025/04/inclusive-dark-mode-designing-accessible-dark-themes/ — why our dark theme is warm-dark not black, desaturated accents, halation.
- Kalamuna, **Alert banner best practices** · https://www.kalamuna.com/blog/alert-banner-best-practices-web-design-disaster-part-1 — one banner, one action.
- **WCAG 2.2** · https://www.w3.org/TR/WCAG22/ — target AA.

## Tools & assets

- **Fonts** (all open, self-host via Fontsource https://fontsource.org/): Fraunces (in repo) · IBM Plex Sans (in repo) · Atkinson Hyperlegible Next https://fonts.google.com/specimen/Atkinson+Hyperlegible+Next (optional body upgrade) · Lexend (alternative).
- **Color/contrast:** Huetone https://huetone.ardov.me/ · Accessible Palette https://accessiblepalette.com/ · OKLCH picker https://oklch.com/ · Radix Colors https://www.radix-ui.com/colors (repo already uses Radix primitives).
- **Components:** shadcn/ui https://ui.shadcn.com/ (repo already uses its token structure + cmdk) · Lucide icons https://lucide.dev/ (in repo).
- **Search:** Pagefind https://pagefind.app/ (in repo — restyle the modal, keep the engine).
- **Testing:** Lighthouse/axe for a11y; Playwright screenshot diffing across the five templates × {light, dark} × {390px, 1440px} makes a good regression harness during the redesign.

## Framework research sources (for 04)

VitePress https://vitepress.dev/ (routing: /guide/routing) · Starlight https://starlight.astro.build/ (showcase: /resources/showcase/ · overrides: /guides/overriding-components/) · comparisons: https://www.pkgpulse.com/guides/best-documentation-frameworks-2026 · https://gautamkhorana.com/static-site-generators/compare/starlight-vs-vitepress/ · Rspress 2.0: https://rspress.rs/blog/rspress-v2 · Nextra 4: https://the-guild.dev/blog/nextra-4
